Install:
	1. Download and extract [cursor].zip
	2. Open the extracted folder
	3. Right click "~install.inf" file
	4. Click "install"
	5. Navigate to Settings > Devices > Mouse > Additional Mouse Options > Pointers
	6. Select the desired Scheme from drop down menu
	7. Hit "OK"


UPON USING YOU AGREE THAT:

	1. This distribution is for personal use only
	2. You will NOT distribute or reupload it in any form
	3. You will NOT claim this work as your own and/or imply ownership
	4. You MAY alter the files (i.e. with a cursor editting program, for speed, color, etc.)
	   ONLY for personal use

Note:
	The files will be installed in your "C:\Windows\Cursors\[...]" directory

�2022 raylark